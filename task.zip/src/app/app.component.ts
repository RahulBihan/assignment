import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'loginbold';
  formGroup;
  firstLetter: string = 'F';
  lastLetter: string = 'L';

  constructor(
    private formBuilder: FormBuilder
  ) {
    this.formGroup = this.formBuilder.group({
      first: '',
      last: '',
      gender: '',
    });
  }

  onSubmit(formData) {
    console.log(formData);
    this.firstLetter = formData['first'].split(' ').map(n => n[0]).join('').toUpperCase();
    this.lastLetter = formData['last'].split(' ').map(n => n[0]).join('').toUpperCase();
  }
  onClick($event) {
    this.firstLetter = 'F';
    this.lastLetter = 'L';
  }



}