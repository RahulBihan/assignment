# Loginbold

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 9.1.8.


-------------Open the given folder in VS Code and run following commands (or open nodejs command prompt and traverse to the folder location and run following commands)

## Install Dependencies

Run `npm install` for a downloading dependencies. 

## Run on Browser

Run `ng serve' . Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.



/////////// Angular 7 used to write TS code.
////////// HTML for template design.
///////// SCSS for styling.

